document.addEventListener("DOMContentLoaded", () => {
    // ==================== EASTER EGG ====================
    let logoClickCount = 0;
    let lastClickTime = 0;
    let easterEggAttempts = 3;
    let currentLanguageIndex = 0;

    const languages = [
        {
            name: "ruso",
            question: "Кто является командой разработчиков этого проекта?",
            fontFamily: "Arial, sans-serif",
            color: "#333"
        },
        {
            name: "alemán",
            question: "Wer ist das Entwicklerteam dieses Projekts?",
            fontFamily: "Arial, sans-serif",
            color: "#333"
        },
        {
            name: "árabe",
            question: "من هو فريق تطوير هذا المشروع؟",
            fontFamily: "Arial, sans-serif",
            color: "#333"
        },
        {
            name: "chino",
            question: "谁是这个项目的开发团队？",
            fontFamily: "Arial, sans-serif",
            color: "#333"
        }
    ];

    const aggressiveStyles = [
        { fontFamily: "Impact, Haettenschweiler, sans-serif", color: "#ff0000" },
        { fontFamily: "Arial Black, Gadget, sans-serif", color: "#8b0000" },
        { fontFamily: "Comic Sans MS, cursive, sans-serif", color: "#ff4500" }
    ];

    const correctMorse = "-... .. -. .--- ..- / - . .- -- -.";

    const brandZone = document.getElementById('brandZone');
    const mainLogo = document.getElementById('mainLogo');
    const easterEggModal = document.getElementById('easterEggModal');
    const closeEasterEggBtn = document.getElementById('closeEasterEggModal');
    const easterEggQuestion = document.getElementById('easterEggQuestion');
    const easterEggInput = document.getElementById('easterEggInput');
    const easterEggSubmit = document.getElementById('easterEggSubmit');
    const easterEggAttemptsText = document.getElementById('easterEggAttempts');
    const easterEggContent = document.getElementById('easterEggContent');
    const easterEggTitle = document.getElementById('easterEggTitle');
    const easterEggBody = document.getElementById('easterEggBody');

    function resetEasterEgg() {
        logoClickCount = 0;
        easterEggAttempts = 3;
        currentLanguageIndex = Math.floor(Math.random() * languages.length);
    }

    function getCurrentLanguage() {
        return languages[currentLanguageIndex % languages.length];
    }

    function updateEasterEggUI() {
        const lang = getCurrentLanguage();
        const styleIndex = 3 - easterEggAttempts;
        
        let currentStyle;
        if (styleIndex > 0) {
            currentStyle = aggressiveStyles[Math.min(styleIndex - 1, aggressiveStyles.length - 1)];
        } else {
            currentStyle = lang;
        }

        easterEggQuestion.textContent = lang.question;
        easterEggQuestion.style.fontFamily = currentStyle.fontFamily;
        easterEggQuestion.style.color = currentStyle.color;
        easterEggQuestion.style.fontSize = styleIndex > 0 ? `${18 + styleIndex * 4}px` : "18px";
        easterEggQuestion.style.fontWeight = styleIndex > 0 ? "bold" : "normal";
        
        easterEggAttemptsText.textContent = `Intentos restantes: ${easterEggAttempts}`;
        
        easterEggInput.value = '';
        easterEggInput.placeholder = "Ingrese la respuesta en código Morse...";
    }

    function openEasterEggModal() {
        currentLanguageIndex = Math.floor(Math.random() * languages.length);
        easterEggAttempts = 3;
        updateEasterEggUI();
        easterEggModal.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function showFinalMessage() {
        easterEggBody.innerHTML = `
            <div style="text-align: center;">
                <h2 style="color: #ff0000; font-size: 32px; font-family: Impact, sans-serif;">⚠️ ACCESO DENEGADO ⚠️</h2>
                <div style="margin: 30px 0;">
                    <img src="https://coreva-normal.trae.ai/api/ide/v1/text_to_image?prompt=access%20denied%20security%20alert%20dramatic&image_size=square" alt="Acceso Denegado" style="max-width: 100%; border-radius: 10px;">
                </div>
                <p style="color: #666; margin-top: 20px;">Cerrando ventana...</p>
            </div>
        `;
        
        setTimeout(() => {
            window.close();
        }, 3000);
    }

    function showSuccessMessage() {
        easterEggBody.innerHTML = `
            <div style="text-align: center;">
                <h2 style="color: #28a745; font-size: 28px;">🎉 ¡Bienvenido! 🎉</h2>
                <div style="margin: 30px 0;">
                    <p style="font-size: 18px; line-height: 1.8;">
                        [Aquí aparecerá el mensaje que quieres colocar]
                    </p>
                    <p style="margin-top: 20px; color: #666;">
                        Desarrollado con ❤️ por el Binju Team
                    </p>
                </div>
            </div>
        `;
    }

    function checkAnswer() {
        const answer = easterEggInput.value.trim().toLowerCase();
        
        if (answer === correctMorse) {
            showSuccessMessage();
        } else {
            easterEggAttempts--;
            
            if (easterEggAttempts <= 0) {
                showFinalMessage();
            } else {
                currentLanguageIndex++;
                updateEasterEggUI();
                Swal.fire({
                    icon: 'error',
                    title: 'Respuesta incorrecta',
                    text: `Te quedan ${easterEggAttempts} intentos`,
                    confirmButtonColor: '#850000'
                });
            }
        }
    }

    // Logo click handler
    if (brandZone || mainLogo) {
        const clickTarget = brandZone || mainLogo;
        
        clickTarget.addEventListener('click', (e) => {
            const now = Date.now();
            
            if (now - lastClickTime > 2000) {
                logoClickCount = 0;
            }
            
            logoClickCount++;
            lastClickTime = now;
            
            if (logoClickCount >= 10) {
                e.preventDefault();
                logoClickCount = 0;
                openEasterEggModal();
            } else if (logoClickCount >= 7) {
                mainLogo.style.transform = `scale(${1 + (logoClickCount - 7) * 0.1}) rotate(${(logoClickCount - 7) * 5}deg)`;
                setTimeout(() => {
                    mainLogo.style.transform = '';
                }, 200);
            } else if (logoClickCount === 1) {
                setTimeout(() => {
                    if (logoClickCount === 1) {
                        window.location.href = window.homeUrl || '/';
                    }
                }, 300);
            }
        });
    }

    // Easter egg modal controls
    if (closeEasterEggBtn && easterEggModal) {
        closeEasterEggBtn.onclick = () => {
            easterEggModal.classList.remove("open");
            document.body.style.overflow = '';
            resetEasterEgg();
        }
    }

    if (easterEggSubmit) {
        easterEggSubmit.onclick = checkAnswer;
    }

    if (easterEggInput) {
        easterEggInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                checkAnswer();
            }
        });
    }

    window.addEventListener('click', (event) => {
        if (event.target == easterEggModal) {
            easterEggModal.classList.remove("open");
            document.body.style.overflow = '';
            resetEasterEgg();
        }
    });
});
